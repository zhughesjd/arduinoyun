﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    class Hours
    {
        public string client;
        public string contract;
        public string projects;
        public decimal mon;
        public decimal tue;
        public decimal wed;
        public decimal thu;
        public decimal fri;
        public decimal sat;
        public decimal sun;

        public Hours(string text1, string text2, string text3, decimal value1, decimal value2, decimal value3, decimal value4, decimal value5, decimal value6, decimal value7)
        {
            this.client = text1;
            this.contract = text2;
            this.projects = text3;
            this.mon = value1;
            this.tue = value2;
            this.wed = value3;
            this.thu = value4;
            this.fri = value5;
            this.sat = value6;
            this.sun = value7;
        }
    }
}
