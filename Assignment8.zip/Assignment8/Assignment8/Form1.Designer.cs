﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Assignment8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.employeeName = new System.Windows.Forms.TextBox();
            this.supervisorName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.reportingPeriodWeek = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.monCheck = new System.Windows.Forms.CheckBox();
            this.tueCheck = new System.Windows.Forms.CheckBox();
            this.wedCheck = new System.Windows.Forms.CheckBox();
            this.thuCheck = new System.Windows.Forms.CheckBox();
            this.friCheck = new System.Windows.Forms.CheckBox();
            this.satCheck = new System.Windows.Forms.CheckBox();
            this.sunCheck = new System.Windows.Forms.CheckBox();
            this.client = new System.Windows.Forms.TextBox();
            this.contract = new System.Windows.Forms.TextBox();
            this.projects = new System.Windows.Forms.TextBox();
            this.monBox = new System.Windows.Forms.NumericUpDown();
            this.tueBox = new System.Windows.Forms.NumericUpDown();
            this.wedBox = new System.Windows.Forms.NumericUpDown();
            this.thuBox = new System.Windows.Forms.NumericUpDown();
            this.friBox = new System.Windows.Forms.NumericUpDown();
            this.satBox = new System.Windows.Forms.NumericUpDown();
            this.sunBox = new System.Windows.Forms.NumericUpDown();
            this.undertime = new System.Windows.Forms.CheckBox();
            this.enterHours = new System.Windows.Forms.Button();
            this.sheet = new System.Windows.Forms.Label();
            this.calculation = new System.Windows.Forms.Label();
            this.submit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.reportingPeriodWeek)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.monBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tueBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wedBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thuBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.friBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.satBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sunBox)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employee Name:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // employeeName
            // 
            this.employeeName.Location = new System.Drawing.Point(149, 12);
            this.employeeName.Name = "employeeName";
            this.employeeName.Size = new System.Drawing.Size(120, 20);
            this.employeeName.TabIndex = 4;
            this.employeeName.Text = "Default Text";
            this.employeeName.TextChanged += new System.EventHandler(this.employeeName_TextChanged_1);
            this.employeeName.LostFocus += new System.EventHandler(this.txtLostFocus);
            // 
            // supervisorName
            // 
            this.supervisorName.CausesValidation = false;
            this.supervisorName.Location = new System.Drawing.Point(149, 41);
            this.supervisorName.Name = "supervisorName";
            this.supervisorName.Size = new System.Drawing.Size(120, 20);
            this.supervisorName.TabIndex = 6;
            this.supervisorName.Text = "Default Text";
            this.supervisorName.TextChanged += new System.EventHandler(this.textBox2_TextChanged_1);
            this.supervisorName.LostFocus += new System.EventHandler(this.txtLostFocus);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Supervisor Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Reporting Period Week:";
            this.label2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // reportingPeriodWeek
            // 
            this.reportingPeriodWeek.Location = new System.Drawing.Point(149, 74);
            this.reportingPeriodWeek.Maximum = new decimal(new int[] {
            52,
            0,
            0,
            0});
            this.reportingPeriodWeek.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.reportingPeriodWeek.Name = "reportingPeriodWeek";
            this.reportingPeriodWeek.Size = new System.Drawing.Size(120, 20);
            this.reportingPeriodWeek.TabIndex = 8;
            this.reportingPeriodWeek.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.reportingPeriodWeek.ValueChanged += new System.EventHandler(this.reportingPeriodWeek_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 182);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Client";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(182, 182);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Contract";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(287, 182);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Project(s)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(501, 180);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(28, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Mon";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(574, 180);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(31, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "Tues";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(659, 180);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 13);
            this.label10.TabIndex = 15;
            this.label10.Text = "Wed";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(741, 180);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 13);
            this.label11.TabIndex = 16;
            this.label11.Text = "Thurs";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(844, 180);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(18, 13);
            this.label12.TabIndex = 17;
            this.label12.Text = "Fri";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(934, 182);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(23, 13);
            this.label13.TabIndex = 18;
            this.label13.Text = "Sat";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(1017, 180);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(26, 13);
            this.label14.TabIndex = 19;
            this.label14.Text = "Sun";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(479, 154);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(622, 13);
            this.label15.TabIndex = 20;
            this.label15.Text = resources.GetString("label15.Text");
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(478, 94);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(622, 13);
            this.label16.TabIndex = 21;
            this.label16.Text = resources.GetString("label16.Text");
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(698, 107);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(141, 13);
            this.label17.TabIndex = 22;
            this.label17.Text = "Weekend/Holiday/Vacation";
            // 
            // monCheck
            // 
            this.monCheck.AutoSize = true;
            this.monCheck.Location = new System.Drawing.Point(504, 137);
            this.monCheck.Name = "monCheck";
            this.monCheck.Size = new System.Drawing.Size(15, 14);
            this.monCheck.TabIndex = 23;
            this.monCheck.UseVisualStyleBackColor = true;
            this.monCheck.CheckedChanged += new System.EventHandler(this.checkChanged);
            // 
            // tueCheck
            // 
            this.tueCheck.AutoSize = true;
            this.tueCheck.Location = new System.Drawing.Point(590, 137);
            this.tueCheck.Name = "tueCheck";
            this.tueCheck.Size = new System.Drawing.Size(15, 14);
            this.tueCheck.TabIndex = 24;
            this.tueCheck.UseVisualStyleBackColor = true;
            this.tueCheck.CheckedChanged += new System.EventHandler(this.checkChanged);
            // 
            // wedCheck
            // 
            this.wedCheck.AutoSize = true;
            this.wedCheck.Location = new System.Drawing.Point(674, 137);
            this.wedCheck.Name = "wedCheck";
            this.wedCheck.Size = new System.Drawing.Size(15, 14);
            this.wedCheck.TabIndex = 25;
            this.wedCheck.UseVisualStyleBackColor = true;
            this.wedCheck.CheckedChanged += new System.EventHandler(this.checkChanged);
            // 
            // thuCheck
            // 
            this.thuCheck.AutoSize = true;
            this.thuCheck.Location = new System.Drawing.Point(760, 137);
            this.thuCheck.Name = "thuCheck";
            this.thuCheck.Size = new System.Drawing.Size(15, 14);
            this.thuCheck.TabIndex = 26;
            this.thuCheck.UseVisualStyleBackColor = true;
            this.thuCheck.CheckedChanged += new System.EventHandler(this.checkChanged);
            // 
            // friCheck
            // 
            this.friCheck.AutoSize = true;
            this.friCheck.Location = new System.Drawing.Point(847, 137);
            this.friCheck.Name = "friCheck";
            this.friCheck.Size = new System.Drawing.Size(15, 14);
            this.friCheck.TabIndex = 27;
            this.friCheck.UseVisualStyleBackColor = true;
            this.friCheck.CheckedChanged += new System.EventHandler(this.checkChanged);
            // 
            // satCheck
            // 
            this.satCheck.AutoSize = true;
            this.satCheck.Checked = true;
            this.satCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.satCheck.Location = new System.Drawing.Point(942, 137);
            this.satCheck.Name = "satCheck";
            this.satCheck.Size = new System.Drawing.Size(15, 14);
            this.satCheck.TabIndex = 28;
            this.satCheck.UseVisualStyleBackColor = true;
            this.satCheck.CheckedChanged += new System.EventHandler(this.checkChanged);
            // 
            // sunCheck
            // 
            this.sunCheck.AutoSize = true;
            this.sunCheck.Checked = true;
            this.sunCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.sunCheck.Location = new System.Drawing.Point(1028, 137);
            this.sunCheck.Name = "sunCheck";
            this.sunCheck.Size = new System.Drawing.Size(15, 14);
            this.sunCheck.TabIndex = 29;
            this.sunCheck.UseVisualStyleBackColor = true;
            this.sunCheck.CheckedChanged += new System.EventHandler(this.checkChanged);
            // 
            // client
            // 
            this.client.CausesValidation = false;
            this.client.Location = new System.Drawing.Point(15, 214);
            this.client.Name = "client";
            this.client.Size = new System.Drawing.Size(88, 20);
            this.client.TabIndex = 30;
            this.client.Text = "Default Text";
            this.client.LostFocus += new System.EventHandler(this.txtLostFocus);
            // 
            // contract
            // 
            this.contract.CausesValidation = false;
            this.contract.Location = new System.Drawing.Point(166, 214);
            this.contract.Name = "contract";
            this.contract.Size = new System.Drawing.Size(88, 20);
            this.contract.TabIndex = 31;
            this.contract.Text = "Default Text";
            this.contract.LostFocus += new System.EventHandler(this.txtLostFocus);
            // 
            // projects
            // 
            this.projects.CausesValidation = false;
            this.projects.Location = new System.Drawing.Point(290, 214);
            this.projects.Name = "projects";
            this.projects.Size = new System.Drawing.Size(88, 20);
            this.projects.TabIndex = 32;
            this.projects.Text = "Default Text";
            this.projects.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            this.projects.LostFocus += new System.EventHandler(this.txtLostFocus);
            // 
            // monBox
            // 
            this.monBox.DecimalPlaces = 2;
            this.monBox.Location = new System.Drawing.Point(482, 214);
            this.monBox.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.monBox.Name = "monBox";
            this.monBox.Size = new System.Drawing.Size(47, 20);
            this.monBox.TabIndex = 34;
            // 
            // tueBox
            // 
            this.tueBox.DecimalPlaces = 2;
            this.tueBox.Location = new System.Drawing.Point(558, 214);
            this.tueBox.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.tueBox.Name = "tueBox";
            this.tueBox.Size = new System.Drawing.Size(47, 20);
            this.tueBox.TabIndex = 35;
            // 
            // wedBox
            // 
            this.wedBox.DecimalPlaces = 2;
            this.wedBox.Location = new System.Drawing.Point(642, 215);
            this.wedBox.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.wedBox.Name = "wedBox";
            this.wedBox.Size = new System.Drawing.Size(47, 20);
            this.wedBox.TabIndex = 36;
            // 
            // thuBox
            // 
            this.thuBox.DecimalPlaces = 2;
            this.thuBox.Location = new System.Drawing.Point(728, 215);
            this.thuBox.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.thuBox.Name = "thuBox";
            this.thuBox.Size = new System.Drawing.Size(47, 20);
            this.thuBox.TabIndex = 37;
            // 
            // friBox
            // 
            this.friBox.DecimalPlaces = 2;
            this.friBox.Location = new System.Drawing.Point(815, 215);
            this.friBox.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.friBox.Name = "friBox";
            this.friBox.Size = new System.Drawing.Size(47, 20);
            this.friBox.TabIndex = 38;
            // 
            // satBox
            // 
            this.satBox.DecimalPlaces = 2;
            this.satBox.Enabled = false;
            this.satBox.Location = new System.Drawing.Point(910, 215);
            this.satBox.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.satBox.Name = "satBox";
            this.satBox.Size = new System.Drawing.Size(47, 20);
            this.satBox.TabIndex = 39;
            // 
            // sunBox
            // 
            this.sunBox.DecimalPlaces = 2;
            this.sunBox.Enabled = false;
            this.sunBox.Location = new System.Drawing.Point(996, 215);
            this.sunBox.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.sunBox.Name = "sunBox";
            this.sunBox.Size = new System.Drawing.Size(47, 20);
            this.sunBox.TabIndex = 40;
            // 
            // undertime
            // 
            this.undertime.AutoSize = true;
            this.undertime.Checked = true;
            this.undertime.CheckState = System.Windows.Forms.CheckState.Checked;
            this.undertime.Enabled = false;
            this.undertime.Location = new System.Drawing.Point(275, 41);
            this.undertime.Name = "undertime";
            this.undertime.Size = new System.Drawing.Size(127, 17);
            this.undertime.TabIndex = 41;
            this.undertime.Text = "not reached 40 hours";
            this.undertime.UseVisualStyleBackColor = true;
            // 
            // enterHours
            // 
            this.enterHours.Location = new System.Drawing.Point(1165, 154);
            this.enterHours.Name = "enterHours";
            this.enterHours.Size = new System.Drawing.Size(95, 34);
            this.enterHours.TabIndex = 42;
            this.enterHours.Text = "Enter Hours";
            this.enterHours.UseVisualStyleBackColor = true;
            this.enterHours.Click += enterHoursClick;
            // 
            // sheet
            // 
            this.sheet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sheet.Location = new System.Drawing.Point(44, 287);
            this.sheet.Name = "sheet";
            this.sheet.Size = new System.Drawing.Size(667, 380);
            this.sheet.TabIndex = 43;
            // 
            // calculation
            // 
            this.calculation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.calculation.Location = new System.Drawing.Point(1028, 287);
            this.calculation.Name = "calculation";
            this.calculation.Size = new System.Drawing.Size(478, 380);
            this.calculation.TabIndex = 44;
            // 
            // submit
            // 
            this.submit.Location = new System.Drawing.Point(1230, 685);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(95, 34);
            this.submit.TabIndex = 45;
            this.submit.Text = "Submit";
            this.submit.UseVisualStyleBackColor = true;
            this.submit.Click += submitClick;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1547, 731);
            this.Controls.Add(this.submit);
            this.Controls.Add(this.calculation);
            this.Controls.Add(this.sheet);
            this.Controls.Add(this.enterHours);
            this.Controls.Add(this.undertime);
            this.Controls.Add(this.sunBox);
            this.Controls.Add(this.satBox);
            this.Controls.Add(this.friBox);
            this.Controls.Add(this.thuBox);
            this.Controls.Add(this.wedBox);
            this.Controls.Add(this.tueBox);
            this.Controls.Add(this.monBox);
            this.Controls.Add(this.projects);
            this.Controls.Add(this.contract);
            this.Controls.Add(this.client);
            this.Controls.Add(this.sunCheck);
            this.Controls.Add(this.satCheck);
            this.Controls.Add(this.friCheck);
            this.Controls.Add(this.thuCheck);
            this.Controls.Add(this.wedCheck);
            this.Controls.Add(this.tueCheck);
            this.Controls.Add(this.monCheck);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.reportingPeriodWeek);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.supervisorName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.employeeName);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.reportingPeriodWeek)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.monBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tueBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wedBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thuBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.friBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.satBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sunBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        //            this.enterHours.Click += enterHoursClick;
//            this.submit.Click += submitClick;
        List<Hours> hoursList = new List<Hours>();
        string spaces = "       ";
        private void submitClick(object sender, EventArgs e)
        {
            decimal totalHours = 0;
            decimal mon = 0;
            decimal tue = 0;
            decimal wed = 0;
            decimal thu = 0;
            decimal fri = 0;
            decimal sat = 0;
            decimal sun = 0;
            foreach (Hours hr in hoursList)
            {
                decimal total = hr.mon + hr.tue + hr.wed + hr.thu + hr.fri + hr.sat + hr.sun;
                totalHours += total;
                mon += hr.mon;
                tue += hr.tue;
                wed += hr.wed;
                thu += hr.thu;
                fri += hr.fri;
                sat += hr.sat;
                sun += hr.sun;
            }
            if((mon == 0 && !monCheck.Checked) || (tue == 0 && !tueCheck.Checked) || (wed == 0 && !wedCheck.Checked) || (thu == 0 && !thuCheck.Checked) || (fri == 0 && !friCheck.Checked) || (sat == 0 && !satCheck.Checked) || (sun == 0 && !sunCheck.Checked))
            {
                MessageBox.Show("There is a work day with no hours.");
                return;
            }
            string text = "Payroll information for "+employeeName.Text+" for the week ending Week "+reportingPeriodWeek.Value+"\n\n";

            decimal regularHoursWorked = Math.Min(40, totalHours);
            decimal ratePerRegHour = 15;
            decimal rPay = regularHoursWorked * ratePerRegHour;

            decimal overtimeHoursWorked = Math.Max(0, totalHours-40);
            decimal ratePerOvertimeHour = ratePerRegHour * new decimal(1.5);
            decimal oPay = overtimeHoursWorked * ratePerOvertimeHour;

            decimal gPay = oPay + rPay;
            text += "Total Hours Worked:" + spaces + totalHours + "\n\n\n";

            text += "Regular Hours Worked:" + spaces + regularHoursWorked + "\n";
            text += "Rate per regular work hour:" + spaces + "$" + ratePerRegHour + "\n";
            text += "                           ------------------------------------------------\n";
            text += "Regular Hourly Pay:" + spaces + "$" + rPay + "\n\n\n";

            text += "OverTime Hours Worked:" + spaces + overtimeHoursWorked + "\n";
            text += "Rate per overtime work hour:" + spaces + "$" + ratePerOvertimeHour + "\n";
            text += "                           ------------------------------------------------\n";
            text += "OverTime Hourly Pay:" + spaces + "$" + oPay + "\n\n\n";

            text += "Gross Pay:" + spaces + "$" + gPay + "\n\n\n";

            int offDay = 0;
            if (monCheck.Checked == true) offDay++;
            if (tueCheck.Checked == true) offDay++;
            if (wedCheck.Checked == true) offDay++;
            if (thuCheck.Checked == true) offDay++;
            if (friCheck.Checked == true) offDay++;
            if (satCheck.Checked == true) offDay++;
            if (sunCheck.Checked == true) offDay++;
            text += "Number of Weekend/Holiday/Vacation days claimed:" + spaces + offDay + "\n";
            calculation.Text = text;
        }
        private void enterHoursClick(object sender, EventArgs e)
        {
                monCheck.Enabled = false;
            tueCheck.Enabled = false;
            wedCheck.Enabled = false;
            thuCheck.Enabled = false;
            friCheck.Enabled = false;
            satCheck.Enabled = false;
            sunCheck.Enabled = false;
            Hours hours = new Hours(client.Text, contract.Text,projects.Text, monBox.Value, tueBox.Value, wedBox.Value, thuBox.Value, friBox.Value, satBox.Value, sunBox.Value);
            if (add(hoursList, hours))
                sheet.Text = getSheetText();
            else
                MessageBox.Show("Total hours for a work day exceeds 24");
            monBox.Value = 0;
            tueBox.Value = 0;
            wedBox.Value = 0;
            thuBox.Value = 0;
            friBox.Value = 0;
            satBox.Value = 0;
            sunBox.Value = 0;
        }

        private bool add(List<Hours> hoursList, Hours hours)
        {
            decimal mon = hours.mon;
            decimal tue = hours.tue;
            decimal wed = hours.wed;
            decimal thu = hours.thu;
            decimal fri = hours.fri;
            decimal sat = hours.sat;
            decimal sun = hours.sun;
            foreach (Hours hr in hoursList)
            {
                mon += hr.mon;
                tue += hr.tue;
                wed += hr.wed;
                thu += hr.thu;
                fri += hr.fri;
                sat += hr.sat;
                sun += hr.sun;
            }
            if(mon  > 24 || tue > 24 || wed > 24 || thu > 24 || fri > 24 || sat > 24 || sun > 24)
            {
                return false;
            }
            monBox.Maximum = 24 - mon;
            tueBox.Maximum = 24 - tue;
            wedBox.Maximum = 24 - wed;
            thuBox.Maximum = 24 - thu;
            friBox.Maximum = 24 - fri;
            satBox.Maximum = 24 - sat;
            sunBox.Maximum = 24 - sun;
            hoursList.Add(hours);
            return true;
        }

        private string getSheetText()
        {
            string text = "Employee Name:" + employeeName.Text + "\n";
            text += "Supervisor Name:" + supervisorName.Text + "\n\n";
            text += "Reporting period:" + reportingPeriodWeek.Value + "\n\n";
            text += "Client" + spaces + "Contract" + spaces + "Project(s)" + spaces + "Mon" + spaces + "Tues" + spaces + "Wed" + spaces + "Thurs" + spaces + "Fri" + spaces + "Sat" + spaces + "Sun" + spaces + "Totals\n";
            text += "---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";
            decimal totalHours = 0;
            decimal mon = 0;
            decimal tue = 0;
            decimal wed = 0;
            decimal thu = 0;
            decimal fri = 0;
            decimal sat = 0;
            decimal sun = 0;
            foreach (Hours hr in hoursList)
            {
                decimal total = hr.mon + hr.tue + hr.wed + hr.thu + hr.fri + hr.sat + hr.sun;
                totalHours += total;
                text += hr.client + spaces + hr.contract + spaces + hr.projects + spaces + hr.mon + spaces + hr.tue + spaces + hr.wed + spaces + hr.thu + spaces + hr.fri + spaces + hr.sat + spaces + hr.sun + spaces + total+"\n";
                mon += hr.mon;
                tue += hr.tue;
                wed += hr.wed;
                thu += hr.thu;
                fri += hr.fri;
                sat += hr.sat;
                sun += hr.sun;
            }
            text += "---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";
            text += "Totals                                                                " + mon + spaces + tue + spaces + wed + spaces + thu + spaces + fri + spaces + sat + spaces + sun + spaces + totalHours + "\n";
            undertime.Checked = totalHours < 40;
            return text;
        }
        protected void txtLostFocus(object sender, EventArgs e)
        {
            System.Windows.Forms.TextBox box = (System.Windows.Forms.TextBox)sender;
            if (box.Text.Trim().Equals(""))
                box.Text = "Default Text";
        }
        protected void checkChanged(object sender, EventArgs e)
        {
            monBox.Enabled = !monCheck.Checked;
            if (monCheck.Checked)
            {
                monBox.Value = 0;
            }
            tueBox.Enabled = !tueCheck.Checked;
            if (tueCheck.Checked)
            {
                tueBox.Value = 0;
            }
            wedBox.Enabled = !wedCheck.Checked;
            if (wedCheck.Checked)
            {
                wedBox.Value = 0;
            }
            thuBox.Enabled = !thuCheck.Checked;
            if (thuCheck.Checked)
            {
                thuBox.Value = 0;
            }
            friBox.Enabled = !friCheck.Checked;
            if (friCheck.Checked)
            {
                friBox.Value = 0;
            }
            satBox.Enabled = !satCheck.Checked;
            if (satCheck.Checked)
            {
                satBox.Value = 0;
            }
            sunBox.Enabled = !sunCheck.Checked;
            if (sunCheck.Checked)
            {
                sunBox.Value = 0;
            }
        }

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox employeeName;
        private System.Windows.Forms.TextBox supervisorName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown reportingPeriodWeek;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox monCheck;
        private System.Windows.Forms.CheckBox tueCheck;
        private System.Windows.Forms.CheckBox wedCheck;
        private System.Windows.Forms.CheckBox thuCheck;
        private System.Windows.Forms.CheckBox friCheck;
        private System.Windows.Forms.CheckBox satCheck;
        private System.Windows.Forms.CheckBox sunCheck;
        private System.Windows.Forms.TextBox client;
        private System.Windows.Forms.TextBox contract;
        private System.Windows.Forms.TextBox projects;
        private System.Windows.Forms.NumericUpDown monBox;
        private System.Windows.Forms.NumericUpDown tueBox;
        private System.Windows.Forms.NumericUpDown wedBox;
        private System.Windows.Forms.NumericUpDown thuBox;
        private System.Windows.Forms.NumericUpDown friBox;
        private System.Windows.Forms.NumericUpDown satBox;
        private System.Windows.Forms.NumericUpDown sunBox;
        private System.Windows.Forms.CheckBox undertime;
        private System.Windows.Forms.Button enterHours;
        private System.Windows.Forms.Label sheet;
        private Label calculation;
        private Button submit;
    }

}

